// File: src/app.ts

import express, { Request, Response, NextFunction } from "express";
import path from "path";
import { connectToDatabase, getDb } from "./database";
import dotenv from "dotenv";
import { ObjectId } from "mongodb";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// View engine and static files
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "../public")));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Middleware for input validation
const validateExpenseInput = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const { beschrijving, bedrag, datum } = req.body;
  if (!beschrijving || !bedrag || !datum) {
    return res.status(400).send("Missing required fields.");
  }
  next();
};

// Route: Homepage (Read all expenses)
app.get("/", async (req: Request, res: Response) => {
  try {
    const db = getDb();
    const users = await db.collection("users").find().toArray();
    const expenses = await db.collection("expenses").find().toArray();
    res.render("index", { users, expenses, message: req.query.message });
  } catch (err) {
    console.error("Error fetching data:", err);
    res.status(500).send("Error fetching data.");
  }
});

// Route: Add Expense (Form)
app.get("/add-expense", (req: Request, res: Response) => {
  res.render("add-expense", { message: req.query.message });
});

app.post(
  "/add-expense",
  validateExpenseInput,
  async (req: Request, res: Response) => {
    const {
      beschrijving,
      bedrag,
      datum,
      valuta,
      betaalmethode,
      categorie,
      tags,
      betaald,
    } = req.body;
    const newExpense = {
      beschrijving,
      bedrag: parseFloat(bedrag),
      datum: new Date(datum),
      valuta,
      betaalmethode,
      categorie,
      tags: tags.split(","),
      betaald: betaald === "true",
    };

    try {
      const db = getDb();
      await db.collection("expenses").insertOne(newExpense);
      res.redirect("/?message=Uitgave succesvol toegevoegd.");
    } catch (err) {
      console.error("Error adding expense:", err);
      res.status(500).send("Error adding expense.");
    }
  }
);

// Route: Edit Expense (Form)
app.get("/edit-expense/:id", async (req: Request, res: Response) => {
  try {
    const db = getDb();
    const expense = await db
      .collection("expenses")
      .findOne({ _id: new ObjectId(req.params.id) });
    if (!expense) return res.status(404).send("Expense not found.");
    res.render("edit-expense", { expense });
  } catch (err) {
    console.error("Error fetching expense for editing:", err);
    res.status(500).send("Error fetching expense.");
  }
});

app.post(
  "/edit-expense/:id",
  validateExpenseInput,
  async (req: Request, res: Response) => {
    const {
      beschrijving,
      bedrag,
      datum,
      valuta,
      betaalmethode,
      categorie,
      tags,
      betaald,
    } = req.body;
    const updatedExpense = {
      beschrijving,
      bedrag: parseFloat(bedrag),
      datum: new Date(datum),
      valuta,
      betaalmethode,
      categorie,
      tags: tags.split(","),
      betaald: betaald === "true",
    };

    try {
      const db = getDb();
      const result = await db
        .collection("expenses")
        .updateOne(
          { _id: new ObjectId(req.params.id) },
          { $set: updatedExpense }
        );

      if (result.modifiedCount === 0) {
        return res.status(404).send("Expense not found or no changes made.");
      }
      res.redirect("/?message=Uitgave succesvol bijgewerkt.");
    } catch (err) {
      console.error("Error updating expense:", err);
      res.status(500).send("Error updating expense.");
    }
  }
);

// Route: Delete Expense (Delete)
app.post("/delete-expense/:id", async (req: Request, res: Response) => {
  try {
    const db = getDb();
    const result = await db
      .collection("expenses")
      .deleteOne({ _id: new ObjectId(req.params.id) });

    if (result.deletedCount === 0) {
      return res.status(404).send("Expense not found.");
    }
    res.redirect("/?message=Uitgave succesvol verwijderd.");
  } catch (err) {
    console.error("Error deleting expense:", err);
    res.status(500).send("Error deleting expense.");
  }
});

// Start server
connectToDatabase().then(() => {
  app.listen(port, () =>
    console.log(`Server running on http://localhost:${port}`)
  );
});
