import { MongoClient, Db } from "mongodb";
import dotenv from "dotenv";

dotenv.config();

const url = process.env.MONGODB_URI;
if (!url) {
  throw new Error("MONGODB_URI environment variable is not defined.");
}
const dbName = "expense-manager";

let db: Db;

export const connectToDatabase = async () => {
  const client = new MongoClient(url);
  try {
    await client.connect();
    console.log("Connected to MongoDB");
    db = client.db(dbName);
  } catch (err) {
    console.error("Failed to connect to MongoDB", err);
    throw err;
  }
};

export const getDb = (): Db => {
  if (!db) {
    throw new Error("Database not initialized. Call connectToDatabase first.");
  }
  return db;
};
